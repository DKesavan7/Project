function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (username === 'Admink7' && password === 'kesavan7') {
      alert('Login successful!');
      window.location.href = '/Upload';
    } else {
      alert('Invalid username or password');
    }
  }
  